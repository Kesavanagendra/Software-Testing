$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"e39a3724-2cff-421a-bc2b-99fece0762ca","feature":"Testing rediff myPage","scenario":"User has to test if login on rediff is successful or not","start":1697798061324,"group":1,"content":"","tags":"@register,","end":1697798081349,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});