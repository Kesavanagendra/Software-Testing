package com.sample;

public class Forloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		
//		for(int i=0;i<6;i++) {
//			System.out.println("Hello World");
//		}
		
		
//	-----------------------------------------------------------------------------	
		
		String s = "Learning Java";
		
		for(int i=0;i<s.length();i++) {
			char ch = s.charAt(i);
			System.out.print(ch+" ");
			
		}
		
		
//		-------------------------------------------------------------------
		
//		char ch[] = s.toCharArray();
//		for(int i=0;i<s.length();i++) {
//			char ch[] = s.toCharArray();
//			System.out.print(ch[i]+" ");
//			
//		}
		
		
		
		

	}

}
