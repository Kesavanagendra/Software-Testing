package com.sample;

public class Casting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//	implicit Type casting		
		char c = '2';
		
		int a = c;
		System.out.println("Impicit type casting. value of a is "+a);
		
		
//	Explicit Type casting
		
		double d= 84.6;
		
		int i = (int)d;
		
		System.out.println("Explicit type casting. value of i is "+i);
		

	}

}
