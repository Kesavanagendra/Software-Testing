package com.sample;

public class DoWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i=11;
		do {
			
			System.out.println(" value is "+i);
			i++;
		}while(i<=10);
	}

}
