package com.app.Junit;

import org.junit.jupiter.api.Test;

public class TestAnnotation {

	@Test
	public void Method1() {
		System.out.println("Hello Junit");
	}
}
