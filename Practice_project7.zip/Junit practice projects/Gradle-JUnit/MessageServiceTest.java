package com.app.gradleDemo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class MessageServiceTest {

	@DisplayName("Test MessageService.get()")
	@Test
	void testGet() {
		Assertions.assertEquals("Hello JUnit 5" , MessageService.get());
	}
}
