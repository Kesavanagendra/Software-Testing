package com.app.gradleDemo;

public class MessageService {

	public static String get() {
		
		return "Hello JUnit 5";
	}
}
