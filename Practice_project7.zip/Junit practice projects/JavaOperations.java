package com.app.Junit;

public class JavaOperations {

}
